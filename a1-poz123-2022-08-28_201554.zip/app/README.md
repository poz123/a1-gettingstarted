

Noah Goodman
https://a1-noahgoodman.glitch.me/

This project shows ...

## Technical Achievements

- added a link and image to the page
- **styled page with CSS:**
- edited color of background and text
- added text shadow and border with respective color
- changed text size
- added a small color changing animation running through the colors of the palette

### Design Achievements

- I used Audiowide from google fonts as the font for the text in my site.
- used the following palette:
  #000000
  #14213D
  #FCA311
  #E5E5E5
  #FFFFFF
  -Link: https://coolors.co/palette/000000-14213d-fca311-e5e5e5-ffffff
  a
